# Metodos-Numericos-2
Algorithms used along the numeric methods 2 lecture. Some of this algorithms are unfinished.
