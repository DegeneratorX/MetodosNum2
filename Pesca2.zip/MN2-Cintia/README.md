# metodos_numericos_2
Trabalhos de métodos numéricos 2
